package com.example.repsyche3;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class MainActivity extends AppCompatActivity {
    EditText email,password;
    Button registerButton,loginButton;
    FirebaseAuth authUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        password = (EditText) findViewById(R.id.passwordInput);
        email = (EditText) findViewById(R.id.emailInput);

        authUser = FirebaseAuth.getInstance();
    }

        public void create(View view){
            if(email.getText().toString().equals("") && password.getText().toString().equals("")){
                Toast.makeText(this, "Provide email & password", Toast.LENGTH_SHORT).show();
            }else {

                String eeemail = email.getText().toString();
                String passssword = password.getText().toString();
                authUser.createUserWithEmailAndPassword(eeemail,passssword)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(MainActivity.this, "Sign-up Complete", Toast.LENGTH_SHORT).show();
                                    finish();

                                   Intent int1=new Intent(MainActivity.this,Credit_Interface.class);
                                    startActivity(int1);
                                }else {
                                    Toast.makeText(MainActivity.this, "User Couldn't Sign-up", Toast.LENGTH_SHORT).show();
                                    Toast.makeText(MainActivity.this, "Try Again", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }

        }

        public void login(View view) {

            if(email.getText().toString().equals("") && password.getText().toString().equals("")) {
                Toast.makeText(this, "Provide email & password", Toast.LENGTH_SHORT).show();
            }else {

                String eeemial = email.getText().toString();
                String paaassword = password.getText().toString();
                authUser.signInWithEmailAndPassword(eeemial,paaassword)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(MainActivity.this, "Log-in Complete", Toast.LENGTH_SHORT).show();
                                    finish();
                                    // open new screen here
                                    Intent int1=new Intent(MainActivity.this,Credit_Interface.class);
                                    startActivity(int1);
                                }else {
                                    Toast.makeText(MainActivity.this, "User Couldn't Log-in", Toast.LENGTH_SHORT).show();
                                    Toast.makeText(MainActivity.this, "Try Again", Toast.LENGTH_SHORT).show();
                                }

                            }
                        });
            }

        }
    }

