package com.example.repsyche3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;



public class Credit_Interface extends AppCompatActivity {
 ImageView imageView;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit__interface);

        imageView =(ImageView) findViewById(R.id.imageView);


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1 = new Intent(Credit_Interface.this, Scanner.class);
                startActivity(int1);

            }
        });



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.drop_down,menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.first:
                Toast.makeText(this, "Loading Buy Page",Toast.LENGTH_SHORT).show();
                finish();

                Intent int1=new Intent(Credit_Interface.this,PaymentSystem.class);
                startActivity(int1);
                        return true;
            case R.id.second:
                Toast.makeText(this, "Loading Previous Transactions",Toast.LENGTH_SHORT).show();
                return true;
            default: return super.onOptionsItemSelected(item);


        }
                }

    }


