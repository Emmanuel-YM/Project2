package com.example.repsyche;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Stakeholder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stakeholder);
    }

    protected void ViewUser(View v){
        Intent startNewActivity = new Intent(this, UserDetails.class);
        startActivity(startNewActivity);
        Button button = (Button) v;
    }

    protected void ViewBins(View v){
        Intent startNewActivity2 = new Intent(this, BinDetails.class);
        startActivity(startNewActivity2);
        Button button = (Button) v;
    }
}
